<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <h1 class="text-2xl font-semibold mb-4 text-[#5e5e4a]"><?php echo e($categorieModel->name); ?></h1>
        <div class="flex flex-row">
            <div class="bg-[#ededed] text-[#5e5e4a] w-full rounded-lg shadow-md p-2 m-1 mb-3 text-sm text-center">
                <a href="/products"><?php echo e(__('messages.Voir_tous_les_produits')); ?></a>
            </div>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-[#ededed] text-[#5e5e4a] w-full rounded-lg shadow-md p-2 m-1 mb-3 text-sm text-center">
                    <a href="<?php echo e(route('productsbycategorie', $categorie->slug)); ?>"><?php echo e($categorie->name); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = $categorieModel->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-[#f8f8f8] rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-2 text-[#5e5e4a]"><?php echo e($product->name); ?></h2>
                    <p class="text-[#5e5e4a]"><?php echo e($product->description); ?></p>
                    <p class="text-lg mt-2 text-[#5e5e4a] font-bold"><?php echo e($product->price); ?> $</p>
                    <p class="text-sm text-[#5e5e4a]">Rabais <?php echo e($product->discount); ?>%</p>
                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="mt-4 w-full h-48 object-cover">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Aulab\resources\views/ProductsByCategorie.blade.php ENDPATH**/ ?>