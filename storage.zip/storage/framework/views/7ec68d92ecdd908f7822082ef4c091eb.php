<div class="w-full flex items-center justify-center bg-[#5e5e4a] font-sans h-7 p-2" id="navbar-user">
    <a href="" class="text-white text-center font-sans text-sm uppercase">
        <?php echo e(__('messages.Offres')); ?>

    </a>
</div>
<div class="bg-white min-w-full flex items-center justify-center">
    <div class="w-full md:w-2/4 flex items-start md:items-center justify-end">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('storage/images/LOGO.webp')); ?>" alt="Aulab Logo" />
        </a>
    </div>
    <div class="w-11/12 md:w-1/4 flex items-center justify-center">
        <form class="flex items-center content-stretch">
            <label for="simple-search" class="sr-only">Search</label>
            <input class="h-7 w-3/4 md:w-56 border-none p-1 text-sm bg-[#f2f2f1] placeholder-[#cbcbc6] placeholder:italic"
                type="text" id="simple-search" placeholder="Rechercher..." required>
            <button type="submit" class="bg-[#d5d5d0] p-1 h-7 text-[#90908c]">
                <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                </svg>
                <span class="sr-only">Search</span>
            </button>
        </form>
    </div>
    <div class="flex justify-end w-1/3 px-10">
        <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('login')): ?>
                <div x-data="{ dropdownMenu: false }" class="relative" @click.away="dropdownMenu = false">
                    <button @click="dropdownMenu = ! dropdownMenu"
                        class="flex justify-end items-end p-2 bg-white rounded-md focus:outline-none">
                        <span class="bg-[#5e5e4a] p-1 h-8 w-8 rounded-full">
                            <i class="fa-solid fa-user text-white"></i>
                        </span>
                    </button>
                    <template x-if="true">
                        <div x-show="dropdownMenu"
                            class="absolute right-0 py-2 mt-2 bg-white rounded-md shadow-xl w-44">
                            <a href="<?php echo e(route('login')); ?>"
                                class="block px-4 py-2 text-sm text-gray-300 hover:bg-[#5e5e4a] hover:text-white"
                                role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(__('messages.Login')); ?>

                            </a>
            <?php endif; ?>
            <?php if(Route::has('register')): ?>
                <a href="<?php echo e(route('register')); ?>"
                    class="block px-4 py-2 text-sm text-gray-300 hover:bg-[#5e5e4a] hover:text-white">
                    <?php echo e(__('messages.Register')); ?>

                </a>
        </div>
        </template>
    </div>
    <?php endif; ?>
<?php else: ?>
    <div x-data="{ dropdownMenu: false }" class="relative" @click.away="dropdownMenu = false">
        <button @click="dropdownMenu = ! dropdownMenu"
            class="flex justify-end items-end p-2 bg-white rounded-md focus:outline-none hover:opacity-90 opacity-100">
            <?php if(Auth::user()->profile_photo): ?>
                <img src="<?php echo e(asset(Auth::user()->profile_photo)); ?>" alt="Profile Photo"
                    class="p-1 h-10 w-10 rounded-full object-cover">
            <?php else: ?>
                <span class="bg-[#5e5e4a] p-1 h-8 w-8 rounded-full">
                    <i class="fa-solid fa-user text-white"></i>
                </span>
            <?php endif; ?>

        </button>
        <template x-if="true">
            <div x-show="dropdownMenu"
                class="absolute right-0 py-2 mt-2 bg-white rounded-md shadow-xl w-44">
                <div class="block px-4 py-2 text-sm text-center">
                    <?php echo e(__('messages.Bienvenue')); ?> <?php echo e(Auth::user()->name); ?> !

                </div>
                <a href="#"
                    class="block px-4 py-2 text-sm text-gray-300 hover:bg-[#5e5e4a] hover:text-white"
                    role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(__('messages.Editer_mon_profil')); ?>

                </a>
                <a href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"
                    class="block px-4 py-2 text-sm text-gray-300 hover:bg-[#5e5e4a] hover:text-white">
                    <?php echo e(__('messages.Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </template>
    </div>
<?php endif; ?>
</div>
</div>
<nav class="w-full flex flex-wrap items-center justify-between mx-auto p-1 bg-[#c1c1ba]">
    <ul class="mx-auto flex flex-col font-medium border-0 rounded-lg md:flex-row md:space-x-8 md:mt-0 md:border-0 text-sm">
        <li>
            <a href="<?php echo e(url('/')); ?>"
                class="block md:py-1 md:px-4 text-[#6d6d5c] rounded md:hover:bg-transparent md:hover:text-white md:p-0 text-sm uppercase font-medium">
                <?php echo e(__('messages.Accueil')); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/products')); ?>"
                class="block md:py-1 md:px-4 text-[#6d6d5c] rounded md:hover:bg-transparent md:hover:text-white md:p-0 text-sm uppercase font-medium">
                <?php echo e(__('messages.Boutique')); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/partners')); ?>"
                class="block md:py-1 md:px-4 text-[#6d6d5c] rounded md:hover:bg-transparent md:hover:text-white md:p-0 text-sm uppercase font-medium">
                <?php echo e(__('messages.Partenaire')); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/blog')); ?>"
                class="block md:py-1 md:px-4 text-[#6d6d5c] rounded md:hover:bg-transparent md:hover:text-white md:p-0 text-sm uppercase font-medium">
                <?php echo e(__('messages.Blog')); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/about')); ?>"
                class="block md:py-1 md:px-4 text-[#6d6d5c] rounded md:hover:bg-transparent md:hover:text-white md:p-0 text-sm uppercase font-medium">
                <?php echo e(__('messages.A_propos_dAulab')); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/contact')); ?>"
                class="block md:py-1 md:px-4 text-[#6d6d5c] rounded md:hover:bg-transparent md:hover:text-white md:p-0 text-sm uppercase font-medium">
                <?php echo e(__('messages.Nous_contacter')); ?>

            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\Aulab\resources\views/components/header.blade.php ENDPATH**/ ?>