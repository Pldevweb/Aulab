<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <h1 class="text-2xl font-semibold mb-4 text-[#5e5e4a]">
            Les articles
        </h1>

        <div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-[#f8f8f8] rounded-lg shadow-md p-6">
                    <h2 class="text-base font-semibold mb-2 text-[#5e5e4a]"><?php echo e($article->title); ?></h2>
                    <img src="<?php echo e($article->thumbnail); ?>" alt="<?php echo e($article->title); ?>" class="mb-2">
                    <p class="text-sm text-[#5e5e4a] text-justify"><?php echo e(substr($article->content, 0, 100) . (strlen($article->content) > 100 ? '...' : '')); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Aulab\resources\views/blog.blade.php ENDPATH**/ ?>